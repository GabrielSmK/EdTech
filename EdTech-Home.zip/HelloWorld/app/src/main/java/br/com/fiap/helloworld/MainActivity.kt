package br.com.fiap.helloworld

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.fiap.helloworld.ui.theme.HelloWorldTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HelloWorldTheme {
                // A surface container using the 'background' color from the theme
                Surface (
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
                ) {
                    LayoutScreen()
                }
                    }

                }
            }
        }



@Composable
fun LayoutScreen() {


    Column(modifier = Modifier.padding(32.dp)) {



        Text(
            text = "EdTech",
            textAlign = TextAlign.Center,
            fontSize = 48.sp,

            )

        Spacer(modifier = Modifier.height(40.dp))


        Text(
            text = "Bem-vindo(a) [Usuário]",
            textAlign = TextAlign.Center,
            fontSize = 35.sp,
            lineHeight = 40.sp,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Continue aprendendo e desbloqueie o poder do seu cérebro",
            textAlign = TextAlign.Center,
            fontSize = 30.sp,
            letterSpacing = 0.15.sp,
            lineHeight = 40.sp,
        )
        Button(
            onClick = { /*TODO*/ },
            modifier = Modifier
                .size(width = 250.dp, height = 48.dp)
                .offset(x = 50.dp, y = 15.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Yellow,
                contentColor = Color.Black
            )
        ) {
            Text(text = "Continuar aprendendo")
        }


        Spacer(modifier = Modifier.height(315.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = { /* do something */ }) {

                Icon(

                    Icons.Filled.Home,

                    contentDescription = "Home",

                    tint = Color.Black,

                    modifier = Modifier.size(width = 48.dp, height = 48.dp)

                )

            }
            IconButton(onClick = { /* do something */ }) {

                Icon(

                    Icons.Filled.Search,

                    contentDescription = "Search",

                    tint = Color.Black,

                    modifier = Modifier.size(width = 48.dp, height = 48.dp)

                )

            }

            IconButton(onClick = { /* do something */ }) {

                Icon(

                    Icons.Filled.Person,

                    contentDescription = "Profile",

                    tint = Color.Black,

                    modifier = Modifier.size(width = 48.dp, height = 48.dp)

                )

            }
            IconButton(onClick = { /* do something */ }) {

                Icon(

                    Icons.Filled.Settings,

                    contentDescription = "Settings",

                    tint = Color.Black,

                    modifier = Modifier.size(width = 48.dp, height = 48.dp)

                )

            }
        }
    }



}

fun Surface(color: Color, border: BorderStroke?, shape: RoundedCornerShape, elevation: Dp) {

}

fun Surface(modifier: Modifier, color: Color) {

}


@Preview(showSystemUi = true, showBackground = true)
@Composable
fun LayoutScreenPreview() {
LayoutScreen()

}
